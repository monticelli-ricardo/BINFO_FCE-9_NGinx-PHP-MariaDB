<!DOCTYPE html>
<html xml:lang="en">
<head>
    <title>Basic PHP Example</title>
</head>
<body>
<h1>Basic PHP Example</h1>
<?php
echo "Hi, I'm a PHP script run at ";
print ("<span style='color:red'>" . date(DATE_RFC2822) . "</span>!");
?>
</body>
</html>
